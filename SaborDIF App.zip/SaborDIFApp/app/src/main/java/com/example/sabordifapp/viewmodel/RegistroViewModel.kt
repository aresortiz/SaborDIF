package com.example.sabordifapp.viewmodel

import androidx.lifecycle.ViewModel

class RegistroViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}